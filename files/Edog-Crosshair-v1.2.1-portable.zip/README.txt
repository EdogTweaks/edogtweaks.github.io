﻿EDOG CROSSHAIR  v1.2.1
======================

A custom crosshair for your screen, with a designer, animations, keybinds and a controller option.
It is a see-through window that sits on top of your game. Your clicks pass straight through it, it never takes
focus, and it never changes the game's files or memory.

Install:  run "Edog-Crosshair-Setup-v1.2.1.exe" (no admin rights needed), or use the portable zip and run
          "Edog Crosshair.exe" from anywhere. No .NET install needed either way.

IMPORTANT - set your game to WINDOWED or WINDOWED FULLSCREEN (Borderless). A window can't be drawn over a game
that runs in exclusive fullscreen. In Fortnite: Settings > Video > Window Mode > Windowed Fullscreen.

What's in it
  Crosshairs   Discover, Browse (41 built-in, grouped by game and style) and Saved (your own, with categories,
               favourites, search). Click a card to put it on screen. Right-click for more. Share / Import with
               a share code (copy and paste to a friend).
  Designer     Build your own: lines, centre dot, outline, ring (solid or dashed), shapes, pictures and text,
               as many layers as you like. Move layers on the canvas, scrub numbers by dragging, undo / redo.
               Animate: Fire, Aim and Reload animations (pulse or hold, easing, repeat). Every change shows on
               your screen straight away.
  Keybinds     Show / hide the crosshair from anywhere (default Shift + Alt + Z). Aim: hide it, or switch to another
               crosshair while you aim. Fire / Aim / Reload play the animations. Crosshair shortcuts: one key per
               crosshair. Keyboard, mouse buttons and controller buttons all work. Alt + Shift + arrow keys nudge
               the crosshair one pixel.
  Cursor       Use your crosshair as the Windows mouse pointer: all pointer states or just some, five sizes, a
               click point you choose. "Reset default pointer" puts your normal pointer back exactly as it was.
  Randomizer   Spin for a random crosshair, with filters and silly modifiers (Magic, Big Boi, Disappearing,
               Helicopter). Undo brings your old one back. Has a reduced-motion option.
  Settings     Which screen it is on, show only in game (a list of game programs), size and position (with
               saved positions), profiles, open with Windows, start in the tray, frame rate, controller on / off,
               and how to include or hide the crosshair in recordings and streams.

Good to know
  - Pixel-exact: at size 1.00 one crosshair unit is one screen pixel, and the middle of the crosshair sits on the
    exact middle of the screen. Odd / even thickness is handled for you.
  - The crosshair is drawn by Windows' own window system, so a screen recorder set to "Display Capture" records
    it. "Game Capture" in OBS only records the game itself. Settings > Recording / Streaming can also hide it
    from recordings.
  - Closing the window keeps it running in the tray (right-click the tray icon > Exit to quit).
  - It only LOOKS at your keyboard, mouse and controller to run your keybinds. It never blocks, changes or sends
    any input. Nothing is sent over the internet, and there are no accounts.
  - Controllers: Xbox-style controllers (XInput) work directly. A PlayStation controller works when Steam Input,
    DS4Windows or similar presents it as an Xbox controller.
  - Some games and tournaments don't allow overlays of any kind. Check the rules of the game you play online;
    you use this at your own discretion.
  - The unsigned program may show a Windows SmartScreen warning the first time ("More info" > "Run anyway").

Your data
  %APPDATA%\EdogCrosshair\data.json (settings, profiles, saved crosshairs). A damaged file is kept as data.json.bad
  and a fresh start is made. Changing the mouse pointer saves a backup of the old one in cursor-backup.json first.
  Uninstalling offers to put your pointer back and to delete the data.

Command line (for testing)
  --data-dir <folder>   keep all data somewhere else and run as a separate copy
  --startup             start quietly in the tray (what "Open when Windows starts" uses)
  --quit                ask a running copy to exit (the installer uses this)
  --no-input            don't listen to the keyboard, mouse or controller (for testing)
  --reset-cursor        put the normal Windows mouse pointer back, with no window (the uninstaller uses this)
  --smoke <folder>      start off-screen with the crosshair OFF, save a screenshot of every page and a report, quit

Source: this folder (C# / WPF, .NET 9).
  App:         dotnet publish EdogCrosshair.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o release
  Installer:   compile installer\EdogCrosshair.iss with Inno Setup 6 (output goes to dist\)
  Tests:       tools\CoreTest (headless: crosshair model, pixel-exact geometry, animation, share codes, key combos,
               router, overlay maths, cursor files; 224 checks)
               Debug build:  "Edog Crosshair.exe --selftest <folder>" (228 checks inside the real app: view-model,
               keybinds, cursor, saving, designer, dialogs, and the real overlay window placed off-screen)
