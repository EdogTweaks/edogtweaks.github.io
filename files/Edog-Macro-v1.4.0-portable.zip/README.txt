EDOG MACRO  v1.4.0
==================

Install:  run "Edog-Macro-Setup-v1.4.0.exe" (no admin rights needed), or use the portable zip
          and run "Edog Macro.exe" from anywhere. No .NET install needed either way.

Quick start
  1. KEYBINDS tab: enter the same Edit, Select, Place and build keys you use in Fortnite
     (defaults: Edit F, Select P, Place = Left Click, build keys Z X C V).
  2. DASHBOARD: switch on the macros you want.
  3. Press "Start Macro" (or your hotkey - F8 by default), then jump into Fortnite.
     The macros only run while Fortnite is the active window.
  4. In Fortnite, turn on "Confirm Edit on Release".

Macros
  Drag Macro    Hold your Edit key. Select is auto-held so you can sweep across tiles;
                release Edit to confirm.
  Double Edit   Press the trigger key (Q by default) to play Edit + Select once.
                MACROS tab -> Repeat: Once / Count (set how many times) / While held
                (repeats until you let go of the trigger).
  Auto Build    Press a build key (Wall / Floor / Stairs / Roof) and the piece is placed for
                you the instant it comes up: Edog Macro clicks your Place button right after
                the key press. Tune the delay under MACROS -> Auto Build; clear any build key
                on the Keybinds tab that you don't want auto-placed.

Your settings
  Everything you change (keybinds, switches, sliders) is saved automatically a moment after you
  change it, and loaded again next time you open Edog Macro. The footer shows "All changes saved".
  File: %APPDATA%\EdogMacro\settings.json  (Settings -> "Open folder").

Tips
  - SETTINGS -> "Open when Windows starts" launches Edog Macro quietly in the tray at sign-in.
  - If the macros do nothing while Fortnite runs as administrator, use
    Settings -> "Restart as administrator".
  - To test outside the game, turn off "Only work while Fortnite is focused" (Settings).
  - Windows SmartScreen may warn about an unsigned app the first time: More info -> Run anyway.
  - Uninstall from Windows Settings -> Apps, or the Start menu entry.

Edog Macro only watches the keys you bind. It never records, stores or sends what you type.
Game rules about input automation can change and are stricter in competitive play - check
Epic's current rules and use it at your own discretion.

Source: this folder (C# / WPF, .NET 9).
  App:         dotnet publish EdogMacro.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o release
  Installer:   compile installer\EdogMacro.iss with Inno Setup 6 (output goes to dist\)
  Engine test: tools\EngineTest (uses only F13-F24; refuses to send keys while Fortnite is the
               active window; add --offline to run just the settings checks)
  Test copies: start the app with  --data-dir <folder>  to keep its settings and instance separate
               from your real ones.
