EDOG TWEAKS  v1.2.0
===================

PC tweaks for gaming on Windows 10 / 11: latency, network, Windows, Gaming, FPS Boost, background services
and debloat. Every change can be undone.

Install:  run "Edog-Tweaks-Setup-v1.2.0.exe" (no admin rights needed to install), or use the portable zip
          and run "Edog Tweaks.exe" from anywhere. No .NET install needed either way.
          Edog Tweaks asks for administrator permission when it starts, because changing system settings needs it.
          If you say no it still opens, but read-only.

What's in it
  Dashboard   Live CPU / GPU / RAM load, GPU and board temperature, storage, your PC, quick actions.
  Latency     Priority and power settings that cut input lag (core parking, USB power saving, MSI mode, ...).
  Network     Nagle's algorithm, throttling, DNS (Cloudflare / Google), flush DNS, a Speed Test.
  Windows     Telemetry, tips and ads, background apps, fast startup, hibernation, updates, ...
  Gaming      Game Bar / DVR, fullscreen optimizations, Game Mode, GPU scheduling, mouse acceleration,
              the Sticky Keys pop-up, Fortnite CPU priority.
  FPS Boost   Power plans (Ultimate / High Performance), visual effects, superfetch, search indexing, clean temp files, TRIM.
  Services    A short, curated list of background services that are safe to switch off. On = allowed to run.
  Debloat     Remove Microsoft Store apps you don't use. Apps Windows or your drivers need are locked ("Keep").

How it keeps your PC safe
  - Before it changes a setting it saves the value it replaces. Switching the tweak off puts exactly that back,
    even after a restart. (Saved in %APPDATA%\EdogTweaks\backups.json.)
  - If any step of a tweak fails, the steps already done are rolled back: nothing is left half-changed.
  - A Windows restore point is created before your first change of each session (turn this off in About).
    It needs System Protection to be on in Windows; if it is off you are told.
  - "Undo everything" on the Dashboard reverts every tweak at once.
  - Tweaks marked CAUTION do something you should know about, and ask first.
  - Nothing here switches off Windows Defender or the CPU's security protections, and no driver is installed.
  - Uninstalling offers to put every tweak back first (your tweaks otherwise stay in place, because they live in Windows).
  - Removed Store apps are the one thing "Undo everything" can't bring back; reinstall them from the Microsoft Store.

"Apply Edog Recommended" (Dashboard) switches on a short list of safe tweaks that need no restart.

Good to know
  - Gains depend on your PC. Many of these settings are already on in a well-kept Windows. The biggest wins usually
    come from a good power plan, Game Mode, no background recording and no background clutter.
  - Some tweaks need a restart or a sign-out; they say so, and a banner reminds you.
  - CPU core temperature isn't shown: Windows doesn't share it without a hardware driver, and this app deliberately
    installs none (anti-cheat doesn't like them). GPU temperature works on NVIDIA cards; the "board" line is
    Windows' ACPI thermal zone, which some boards leave fixed.
  - Speed Test only runs when you press it. It pings Cloudflare (1.1.1.1) and uses Cloudflare's public speed-test servers
    for about six seconds each way. Nothing else is ever sent anywhere.
  - Settings are applied to the Windows account that approved the administrator prompt; if you use a different
    admin account to approve it, the per-user tweaks (mouse, Game Bar, ...) apply to that account instead.
  - Game rules can change; check the rules of any game you play online and use tweaks at your own discretion.

Command line (for testing)
  --data-dir <folder>   keep settings and undo data somewhere else (and run as a separate copy)
  --no-elevate          don't ask for administrator rights (read-only)
  --undo-all            put back every change, with no window (the uninstaller uses this)
  --smoke <folder>      start off-screen, read everything, save screenshots + a report there, quit. Changes nothing.

Source: this folder (C# / WPF, .NET 9).
  App:         dotnet publish EdogTweaks.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o release
  Installer:   compile installer\EdogTweaks.iss with Inno Setup 6 (output goes to dist\)
  Tests:       tools\TweakTest (the tweak engine: writes only to memory, a scratch registry area and fakes; reads this PC)
               tools\UiTest    (what happens when a switch is clicked; fakes only)
