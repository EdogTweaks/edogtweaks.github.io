EDOG CONTROLLER MACRO  v1.4.1
=============================

Drag Edit, Double Edit, Reset Edit and Pickup macros for Fortnite on PC, for Xbox AND PlayStation controllers.

Install:  run "Edog-Controller-Macro-Setup-v1.4.1.exe" (no admin rights needed), or use the portable zip
          and run "Edog Controller Macro.exe" from anywhere. No .NET install needed either way.

You also need the free "ViGEmBus" virtual controller driver (Windows can't press controller buttons on its own).
The app checks for it and has a "Get the driver" button. Source: github.com/nefarius/ViGEmBus/releases

Quick start
  1. Connect your controller (USB, Bluetooth or wireless adapter). CONTROLLER tab: it should be listed,
     and light up in the Live test when you press buttons.
       - Xbox controllers: read through Windows (XInput).
       - PlayStation DualShock 4 / DualSense: read directly over USB or Bluetooth.
       - Other pads (Switch Pro, 8BitDo, ...): they work if Windows presents them as Xbox controllers
         (Steam Input, DS4Windows and similar do that).
  2. BUTTONS tab: set Edit and Select to the buttons you use in Fortnite (defaults: Edit = R3, Select = RT /
     R2), pick spare buttons for Double Edit (default: View / Create), Reset Edit and Pickup, and set the
     keyboard action Reset Edit and Pickup perform (default: mouse wheel down / E, as in Fortnite's keyboard binds).
  3. DASHBOARD: switch on the macros you want (Reset Edit and Pickup start switched OFF, because they press
     keys in a live match), then press "Start Macro" (or your keyboard key, F9 by default)
     BEFORE you load into a match. A virtual controller is plugged in while the macros run.
  4. In Fortnite, turn on "Confirm Edit on Release".

Macros
  Drag Edit     Hold your Edit button. Select is auto-held so you can sweep across tiles with the stick;
                release Edit to confirm.
  Double Edit   Press the trigger button to play Edit + Select once. MACROS tab -> Repeat: Once / Count
                (set how many times) / While held (repeats until you let go of the button).
  Reset Edit    Hold a CONTROLLER button and the macro performs your KEYBOARD's reset action over and over:
                the controller version of scrolling the mouse wheel to reset edits. Defaults: hold D-pad
                Down -> mouse wheel down, 16 times per second. In the BUTTONS tab you choose the controller
                button you hold and the keyboard action it performs (press a key, scroll the wheel, or click
                a mouse button; Fortnite's keyboard setting must use the same one). MACROS tab: speed.
  Pickup        Hold a CONTROLLER button and the macro presses your KEYBOARD's Interact key over and over,
                so you pick up every weapon in front of you. Defaults: hold D-pad Up -> the E key, 10 per
                second. Choose the keyboard key in the BUTTONS tab (it must match Fortnite's Interact bind).
                (Picking up repeatedly with a full inventory swaps weapons, so keep the speed sensible.)

  Reset Edit and Pickup are the only macros that send keyboard / mouse input (everything else stays on the
  virtual controller). Because the game then sees a little keyboard input next to your controller, it may
  briefly show keyboard prompts while they run. Both are switched OFF until you turn them on.

How the macro talks to the game (CONTROLLER tab)
  Add-on   (default) Your real controller works as normal. A second, virtual controller only carries the
           macro's presses. Pick a spare button for Double Edit, because the real controller still sends it.
  Mirror   Everything you do is copied onto the virtual controller, plus the macro's presses. This lets the
           macro hide the Double Edit button from the game. Best together with HidHide (hides your real
           controller from Fortnite): github.com/nefarius/HidHide/releases

  Virtual controller type: Auto (matches your real controller: PlayStation pad -> DualShock 4, otherwise
  Xbox 360), or force one. The virtual controller only exists while the macros run.

If something doesn't work
  - Live test doesn't react: the controller isn't being read. Check the cable / pairing, close other programs
    that grab the controller exclusively, press "Scan again".
  - CONTROLLER tab -> "Run test" checks that the virtual controller works at all (do it outside a match).
  - If Fortnite ignores the macro presses in Add-on mode, switch to Mirror mode and hide your real controller
    with HidHide, so the game only sees the virtual one.
  - Settings save automatically (%APPDATA%\EdogControllerMacro\settings.json).

Edog Controller Macro only reads the controller you choose. It never records, stores or sends anything.
Game rules about input automation can change and are stricter in competitive play, and anti-cheat may look at
virtual controllers - check Epic's current rules and use it at your own discretion.

Source: this folder (C# / WPF, .NET 9).
  App:         dotnet publish EdogControllerMacro.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o release
  Installer:   compile installer\EdogControllerMacro.iss with Inno Setup 6 (output goes to dist\)
  Tests:       tools\PadTest (headless; safe while you play). A Debug build also has --selftest, which plugs virtual
               controllers in and checks the whole pipeline; it refuses to run while Fortnite is open.
  Test copies: start the app with  --data-dir <folder>  to keep its settings and instance separate.
